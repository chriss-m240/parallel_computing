export const url = 'host.docker.internal'
export const port = '4000'
export const entryPoint = 'categories'
